/*
  - Class to help pass addEntry as a Navigator arg
*/
class AddEntryScreenArguments {
  final void Function(dynamic) addEntry;

  AddEntryScreenArguments({required this.addEntry});
}
